package com.bignerdranch.android.pomodo

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.bignerdranch.android.pomodo.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val taskList = mutableListOf<TaskWithDeadline>()
    private lateinit var adapter: TaskAdapter

    private var timer: CountDownTimer? = null
    private var timeLeftInMillis: Long = 1500000 // 25 minutes
    private var isTimerRunning = false
    private var selectedDeadline: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize RecyclerView
        adapter = TaskAdapter(taskList) { task -> deleteTask(task) }
        binding.taskRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.taskRecyclerView.adapter = adapter

        // Add Task button functionality
        binding.addTaskButton.setOnClickListener {
            val title = binding.taskTitleInput.text.toString().trim()
            val details = binding.taskDetailsInput.text.toString().trim()

            if (title.isEmpty() || details.isEmpty() || selectedDeadline == null) {
                Toast.makeText(this, "Please complete all fields and set a deadline", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val isOverdue = isTaskOverdue(selectedDeadline!!)
            val task = TaskWithDeadline(title, details, selectedDeadline!!, isOverdue)
            taskList.add(task)
            adapter.notifyDataSetChanged()

            binding.taskTitleInput.text.clear()
            binding.taskDetailsInput.text.clear()
            selectedDeadline = null
        }

        // Set Deadline button functionality
        binding.setDeadlineButton.setOnClickListener {
            showDatePicker()
        }

        // Open Calendar button functionality
        binding.openCalendarButton.setOnClickListener {
            startActivity(Intent(this, DeadlineCalendarActivity::class.java))
        }

        // Timer functionality
        binding.startTimerButton.setOnClickListener { startTimer() }
        binding.pauseTimerButton.setOnClickListener { pauseTimer() }
        binding.resetTimerButton.setOnClickListener { resetTimer() }
    }

    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(this, { _, year, month, dayOfMonth ->
            selectedDeadline = "$year-${month + 1}-$dayOfMonth"
            Toast.makeText(this, "Deadline set to $selectedDeadline", Toast.LENGTH_SHORT).show()
        }, year, month, day)
        datePickerDialog.show()
    }

    private fun isTaskOverdue(deadline: String): Boolean {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val currentDate = sdf.format(Date())
        return currentDate > deadline
    }

    private fun deleteTask(task: TaskWithDeadline) {
        taskList.remove(task)
        adapter.notifyDataSetChanged()
    }

    private fun startTimer() {
        if (isTimerRunning) return

        timer = object : CountDownTimer(timeLeftInMillis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timeLeftInMillis = millisUntilFinished
                updateTimerView()
            }

            override fun onFinish() {
                isTimerRunning = false
                binding.timerView.text = "Done!"
            }
        }.start()
        isTimerRunning = true
    }

    private fun pauseTimer() {
        timer?.cancel()
        isTimerRunning = false
    }

    private fun resetTimer() {
        timer?.cancel()
        timeLeftInMillis = 1500000
        updateTimerView()
        isTimerRunning = false
    }

    private fun updateTimerView() {
        val minutes = (timeLeftInMillis / 1000) / 60
        val seconds = (timeLeftInMillis / 1000) % 60
        binding.timerView.text = String.format("%02d:%02d", minutes, seconds)
    }
}
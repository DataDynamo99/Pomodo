package com.bignerdranch.android.pomodo

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bignerdranch.android.pomodo.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val taskList = mutableListOf<String>() // Stores tasks
    private var timer: CountDownTimer? = null
    private var timeLeftInMillis: Long = 1500000 // 25 minutes
    private var isTimerRunning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Set up view binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up ListView adapter
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, taskList)
        binding.taskListView.adapter = adapter

        // Add Task button functionality
        binding.addTaskButton.setOnClickListener {
            val title = binding.taskTitleInput.text.toString().trim()
            val details = binding.taskDetailsInput.text.toString().trim()
            val startTime = binding.taskStartTime.text.toString().trim()
            val endTime = binding.taskEndTime.text.toString().trim()

            // Validate inputs
            if (title.isEmpty() || details.isEmpty() || startTime.isEmpty() || endTime.isEmpty()) {
                Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Create task string
            val task = "Title: $title\nDetails: $details\nTime: $startTime - $endTime"
            taskList.add(task) // Add to the task list
            adapter.notifyDataSetChanged() // Refresh ListView

            // Clear input fields
            binding.taskTitleInput.text.clear()
            binding.taskDetailsInput.text.clear()
            binding.taskStartTime.text.clear()
            binding.taskEndTime.text.clear()
        }

        // Timer buttons functionality
        binding.startTimerButton.setOnClickListener { startTimer() }
        binding.pauseTimerButton.setOnClickListener { pauseTimer() }
        binding.resetTimerButton.setOnClickListener { resetTimer() }

        // Open Deadline Calendar Activity
        binding.openCalendarButton.setOnClickListener {
            val intent = Intent(this, DeadlineCalendarActivity::class.java)
            startActivity(intent)
        }
    }

    private fun startTimer() {
        if (isTimerRunning) return

        timer = object : CountDownTimer(timeLeftInMillis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timeLeftInMillis = millisUntilFinished
                updateTimerView()
            }

            override fun onFinish() {
                isTimerRunning = false
                binding.timerView.text = "Done!"
            }
        }.start()
        isTimerRunning = true
    }

    private fun pauseTimer() {
        timer?.cancel()
        isTimerRunning = false
    }

    private fun resetTimer() {
        timer?.cancel()
        timeLeftInMillis = 1500000 // Reset to 25 minutes
        updateTimerView()
        isTimerRunning = false
    }

    private fun updateTimerView() {
        val minutes = (timeLeftInMillis / 1000) / 60
        val seconds = (timeLeftInMillis / 1000) % 60
        binding.timerView.text = String.format("%02d:%02d", minutes, seconds)
    }
}
